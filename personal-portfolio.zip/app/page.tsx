import { ChevronDown } from "lucide-react"

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-[#2868c9] text-white p-6 md:p-10">
        <div className="container mx-auto">
          <h1 className="text-4xl md:text-6xl font-bold animate-fadeIn">Rabe56</h1>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 md:py-24 container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6">Willkommen auf meiner Website</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Hier findest du Informationen über meine Fähigkeiten und Projekte.
          </p>
          <div className="mt-10 animate-bounce">
            <ChevronDown className="mx-auto text-[#2868c9]" size={32} />
          </div>
        </div>

        {/* Skills Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-16">
          <SkillCard
            icon="💻"
            title="Web + Java Entwicklung"
            description="Erfahrung in der Entwicklung von Webanwendungen und Java-Projekten mit modernen Technologien und Frameworks."
          />

          <SkillCard
            icon="👨‍💻"
            title="Python Discord Bots"
            description="Entwicklung von maßgeschneiderten Discord-Bots mit Python, die verschiedene Funktionen und Automatisierungen bieten."
          />

          <SkillCard
            icon="🚀"
            title="Linux Console + Ubuntu/Debian"
            description="Umfassende Kenntnisse in Linux-Systemen, insbesondere Ubuntu und Debian, sowie Erfahrung mit der Kommandozeile."
          />
        </div>
      </section>

      {/* Projects Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-12 text-center">Meine Projekte</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <ProjectCard
              title="ZickZack Network"
              description="Ein Netzwerk von Diensten und Anwendungen, die ich entwickelt habe."
              tags={["Web", "Netzwerk", "Services"]}
            />

            <ProjectCard
              title="Discord Bots"
              description="Verschiedene Discord-Bots für unterschiedliche Zwecke und Communities."
              tags={["Python", "Discord", "API"]}
            />

            <ProjectCard
              title="Minecraft Server"
              description="Angepasste Minecraft-Server mit eigenen Plugins und Modifikationen."
              tags={["Java", "Minecraft", "Server"]}
            />

            <ProjectCard
              title="Linux Tools"
              description="Verschiedene Tools und Skripte für Linux-Systeme zur Automatisierung und Verwaltung."
              tags={["Linux", "Bash", "Automation"]}
            />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-10">
        <div className="container mx-auto px-6 text-center">
          <p className="mb-4">© {new Date().getFullYear()} ZickZackNetwork. Alle Rechte vorbehalten.</p>
          <div className="flex justify-center space-x-6">
            <a href="#" className="hover:text-[#2868c9] transition-colors">
              GitHub
            </a>
            <a href="#" className="hover:text-[#2868c9] transition-colors">
              Discord
            </a>
            <a href="#" className="hover:text-[#2868c9] transition-colors">
              Email
            </a>
          </div>
        </div>
      </footer>
    </div>
  )
}

// Skill Card Component
function SkillCard({ icon, title, description }: { icon: string; title: string; description: string }) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100">
      <div className="text-4xl mb-4">{icon}</div>
      <h3 className="text-xl font-bold text-gray-800 mb-3">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  )
}

// Project Card Component
function ProjectCard({ title, description, tags }: { title: string; description: string; tags: string[] }) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-all duration-300">
      <h3 className="text-xl font-bold text-gray-800 mb-3">{title}</h3>
      <p className="text-gray-600 mb-4">{description}</p>
      <div className="flex flex-wrap gap-2">
        {tags.map((tag, index) => (
          <span key={index} className="bg-[#2868c9] bg-opacity-10 text-[#2868c9] px-3 py-1 rounded-full text-sm">
            {tag}
          </span>
        ))}
      </div>
    </div>
  )
}
